import model.*;
import service.*;

import java.util.*;

public class AppLauncher {
    private static Scanner sc = new Scanner(System.in);
    private static JobBoard board = new JobBoard();
    private static List<User> users = FileManager.loadUsers();

    public static void main(String[] args) {
        System.out.println("🛠️ Welcome to Local Job Finder for Daily Wage Workers!");

        while (true) {
            System.out.println("\n1. Sign Up");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose: ");
            int ch = sc.nextInt(); sc.nextLine();

            switch (ch) {
                case 1: signUp(); break;
                case 2: login(); break;
                case 3: System.out.println("👋 Goodbye!"); return;
                default: System.out.println("❌ Invalid choice.");
            }
        }
    }

    // ------------------------ Sign Up ------------------------
    private static void signUp() {
        System.out.print("Enter name: ");
        String name = sc.nextLine();

        System.out.print("Enter phone: ");
        String phone = sc.nextLine();

        System.out.print("Enter password: ");
        String pwd = sc.nextLine();

        System.out.print("Are you a Worker or Employer? ");
        String role = sc.nextLine();

        String id = role.equalsIgnoreCase("Worker") ? "W" + (users.size() + 1) : "E" + (users.size() + 1);
        User user = role.equalsIgnoreCase("Worker")
                  ? new Worker(id, name, phone, pwd)
                  : new Employer(id, name, phone, pwd);

        users.add(user);
        FileManager.saveUser(user);
        System.out.println("✅ Account created! Your ID is " + id);
    }

    // ------------------------ Login ------------------------
    private static void login() {
        System.out.print("Enter user ID: ");
        String id = sc.nextLine();

        System.out.print("Enter password: ");
        String pwd = sc.nextLine();

        for (User u : users) {
            if (u.getId().equals(id) && u.getPassword().equals(pwd)) {
                System.out.println("✅ Logged in as " + u.getName());

                if (u instanceof Worker) {
                    workerMenu((Worker) u);
                } else if (u instanceof Employer) {
                    employerMenu((Employer) u);
                }
                return;
            }
        }

        System.out.println("❌ Invalid credentials.");
    }

    // ------------------------ Worker Menu ------------------------
    private static void workerMenu(Worker w) {
        while (true) {
            System.out.println("\n👷‍♂️ Worker Menu");
            System.out.println("1. View Jobs");
            System.out.println("2. Apply to Job");
            System.out.println("3. My Applications");
            System.out.println("4. Logout");
            System.out.print("Choose: ");
            int ch = sc.nextInt(); sc.nextLine();

            switch (ch) {
                case 1: board.showAllJobs(); break;
                case 2:
                    System.out.print("Enter Job ID: ");
                    String jobId = sc.nextLine();
                    board.applyToJob(w, jobId);
                    break;
                case 3: board.showMyApplications(w); break;
                case 4: return;
                default: System.out.println("❌ Invalid choice.");
            }
        }
    }

    // ------------------------ Employer Menu ------------------------
    private static void employerMenu(Employer e) {
        while (true) {
            System.out.println("\n🏗️ Employer Menu");
            System.out.println("1. Post Job");
            System.out.println("2. My Posted Jobs");
            System.out.println("3. Logout");
            System.out.print("Choose: ");
            int ch = sc.nextInt(); sc.nextLine();

            switch (ch) {
                case 1:
                    System.out.print("Title: ");
                    String title = sc.nextLine();
                    System.out.print("Category: ");
                    String cat = sc.nextLine();
                    System.out.print("Location: ");
                    String loc = sc.nextLine();
                    System.out.print("Daily Wage ₹: ");
                    int wage = sc.nextInt(); sc.nextLine();
                    System.out.print("Description: ");
                    String desc = sc.nextLine();

                    board.postJob(e, title, cat, loc, wage, desc);
                    break;

                case 2: board.showPostedJobs(e); break;
                case 3: return;
                default: System.out.println("❌ Invalid choice.");
            }
        }
    }
}

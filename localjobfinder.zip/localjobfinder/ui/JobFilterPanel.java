package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import model.*;
import service.*;

public class JobFilterPanel extends JPanel {
    private JTextField locationField, categoryField;
    private JTextArea resultsArea;

    public JobFilterPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.white);

        // 🔹 Title
        JLabel title = new JLabel("🔍 Filter Jobs");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        add(title, BorderLayout.NORTH);

        // 🔹 Form Panel
        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(20, 100, 20, 100));
        form.setBackground(Color.white);

        form.add(new JLabel("Location:"));
        locationField = new JTextField();
        form.add(locationField);

        form.add(new JLabel("Category:"));
        categoryField = new JTextField();
        form.add(categoryField);

        JButton filterBtn = new JButton("Filter");
        form.add(new JLabel()); // Empty cell
        form.add(filterBtn);

        add(form, BorderLayout.CENTER);

        // 🔹 Results Area
        resultsArea = new JTextArea(10, 40);
        resultsArea.setEditable(false);
        add(new JScrollPane(resultsArea), BorderLayout.SOUTH);

        // 🔹 Filter Action
        filterBtn.addActionListener(e -> applyFilter());
    }

    private void applyFilter() {
        String loc = locationField.getText().trim().toLowerCase();
        String cat = categoryField.getText().trim().toLowerCase();

        List<Job> allJobs = FileManager.loadJobs();
        resultsArea.setText("");

        for (Job job : allJobs) {
            boolean matchesLoc = loc.isEmpty() || job.getLocation().toLowerCase().contains(loc);
            boolean matchesCat = cat.isEmpty() || job.getCategory().toLowerCase().contains(cat);

            if (matchesLoc && matchesCat) {
                resultsArea.append(String.format(
                    "🆔 %s | 📍 %s | 🧰 %s | 💸 ₹%d\n📄 %s\n\n",
                    job.getJobId(), job.getLocation(), job.getCategory(), job.getWage(), job.getDescription()
                ));
            }
        }

        if (resultsArea.getText().isEmpty()) {
            resultsArea.setText("⚠️ No matching jobs found.");
        }
    }
}

package ui;

import model.*;
import service.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MainWindow extends JFrame {
    private CardLayout layout;
    private JPanel mainPanel;

    public MainWindow() {
        setTitle("Local Job Finder 🛠️");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        layout = new CardLayout();
        mainPanel = new JPanel(layout);

        List<User> users = FileManager.loadUsers();

        LoginPanel login = new LoginPanel(this, users);
        RegisterPanel register = new RegisterPanel(this, users);

        mainPanel.add(login, "login");
        mainPanel.add(register, "register");

        add(mainPanel);
        layout.show(mainPanel, "login");
    }

    public void switchTo(String panelName) {
        layout.show(mainPanel, panelName);
    }

    public void addPanel(String name, JPanel panel) {
        mainPanel.add(panel, name);
    }

    // ✅ Worker dashboard injector
    public void showWorkerDashboard(Worker worker) {
        WorkerDashboardPanel workerPanel = new WorkerDashboardPanel(this, worker, new JobBoard());
        addPanel("worker", workerPanel);
        switchTo("worker");
    }

    // ✅ Employer dashboard injector (if using it)
    public void showEmployerDashboard(Employer employer) {
        EmployerDashboardPanel employerPanel = new EmployerDashboardPanel(this, employer, new JobBoard());
        addPanel("employer", employerPanel);
        switchTo("employer");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainWindow().setVisible(true));
    }
}

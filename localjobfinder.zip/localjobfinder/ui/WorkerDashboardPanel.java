package ui;

import javax.swing.*;
import java.awt.*;
import model.*;
import service.*;

public class WorkerDashboardPanel extends JPanel {
    private MainWindow mainWindow;
    private Worker worker;
    private JobBoard board;

    public WorkerDashboardPanel(MainWindow mainWindow, Worker worker, JobBoard board) {
        this.mainWindow = mainWindow;
        this.worker = worker;
        this.board = board;

        setLayout(new BorderLayout());
        setBackground(Color.white);

        JLabel welcomeLabel = new JLabel("👷 Welcome, " + worker.getName(), SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(welcomeLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 100, 20, 100));

        JButton viewJobsBtn = new JButton("📄 View All Jobs");
        JButton applyJobBtn = new JButton("✅ Apply to Job");
        JButton myAppsBtn = new JButton("📋 My Applications");
        JButton logoutBtn = new JButton("🚪 Logout");
        JButton filterBtn = new JButton("🔍 Filter Jobs");

        // View all jobs
        viewJobsBtn.addActionListener(e -> board.showAllJobs());

        // Apply to job
        applyJobBtn.addActionListener(e -> {
            String jobId = JOptionPane.showInputDialog(this, "Enter Job ID to apply:");
            if (jobId != null && !jobId.trim().isEmpty()) {
                board.applyToJob(worker, jobId.trim());
            }
        });

        // My Applications
        myAppsBtn.addActionListener(e -> board.showMyApplications(worker));

        // Logout
        logoutBtn.addActionListener(e -> mainWindow.switchTo("login"));

        // Filter Jobs
        filterBtn.addActionListener(e -> mainWindow.switchTo("filterJobs"));

        buttonPanel.add(viewJobsBtn);
        buttonPanel.add(applyJobBtn);
        buttonPanel.add(myAppsBtn);
        buttonPanel.add(filterBtn);
        buttonPanel.add(logoutBtn);

        add(buttonPanel, BorderLayout.CENTER);
    }
}

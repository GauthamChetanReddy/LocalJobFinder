package ui;

import model.*;
import service.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MyApplicationsPanel extends JPanel {
    private Worker worker;
    private JobBoard jobBoard;
    private JTable appTable;
    private DefaultTableModel tableModel;

    public MyApplicationsPanel(Worker worker, JobBoard jobBoard) {
        this.worker = worker;
        this.jobBoard = jobBoard;

        setLayout(new BorderLayout());
        setBackground(Color.white);

        JLabel header = new JLabel("📋 My Applications", JLabel.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        add(header, BorderLayout.NORTH);

        // Table columns
        String[] cols = {"App ID", "Job Title", "Location", "Wage", "Status"};
        tableModel = new DefaultTableModel(cols, 0);
        appTable = new JTable(tableModel);
        add(new JScrollPane(appTable), BorderLayout.CENTER);

        loadApplications();
    }

    private void loadApplications() {
        List<Application> apps = jobBoard.getApplicationsByWorker(worker.getId());
        tableModel.setRowCount(0); // Clear old rows

        for (Application app : apps) {
            Job job = jobBoard.getJobById(app.getJobId());
            if (job != null) {
                tableModel.addRow(new Object[]{
                    app.getAppId(),
                    job.getTitle(),
                    job.getLocation(),
                    job.getWage(),
                    app.getStatus()
                });
            }
        }
    }
}

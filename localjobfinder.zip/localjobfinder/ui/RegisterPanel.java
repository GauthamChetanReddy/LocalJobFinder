package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import model.*;
import service.*;

public class RegisterPanel extends JPanel {
    public RegisterPanel(MainWindow window, List<User> users) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        setBackground(Color.WHITE);

        JLabel title = new JLabel("📝 Register");
        title.setFont(new Font("Arial", Font.BOLD, 22));
        JTextField nameField = new JTextField(15);
        JTextField phoneField = new JTextField(15);
        JPasswordField passField = new JPasswordField(15);
        JTextField roleField = new JTextField(15);

        JButton registerBtn = new JButton("Register");
        JButton loginBtn = new JButton("Back to Login");

        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        gbc.gridwidth = 1;

        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1;
        add(phoneField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        add(passField, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        add(new JLabel("Role (Worker/Employer):"), gbc);
        gbc.gridx = 1;
        add(roleField, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        add(registerBtn, gbc);
        gbc.gridx = 1;
        add(loginBtn, gbc);

        registerBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String phone = phoneField.getText().trim();
            String pass = new String(passField.getPassword()).trim();
            String role = roleField.getText().trim();

            // Validation
            if (name.isEmpty() || phone.isEmpty() || pass.isEmpty() || role.isEmpty()) {
                JOptionPane.showMessageDialog(this, "❗ All fields are required.");
                return;
            }

            if (!phone.matches("\\d{10}")) {
                JOptionPane.showMessageDialog(this, "❗ Phone number must be 10 digits.");
                return;
            }

            if (!role.equalsIgnoreCase("Worker") && !role.equalsIgnoreCase("Employer")) {
                JOptionPane.showMessageDialog(this, "❗ Role must be 'Worker' or 'Employer'.");
                return;
            }

            String id = role.equalsIgnoreCase("Worker") ? "W" + (users.size() + 1) : "E" + (users.size() + 1);
            User user = role.equalsIgnoreCase("Worker")
                    ? new Worker(id, name, phone, pass)
                    : new Employer(id, name, phone, pass);

            users.add(user);
            FileManager.saveUser(user);
            JOptionPane.showMessageDialog(this, "✅ Registered! Your ID is " + id);
            window.switchTo("login");
        });

        loginBtn.addActionListener(e -> window.switchTo("login"));
    }
}

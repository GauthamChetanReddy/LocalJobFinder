package ui;

import model.*;
import service.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class LoginPanel extends JPanel {
    private JTextField idField;
    private JPasswordField passwordField;

    public LoginPanel(MainWindow mainWindow, List<User> users) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        setBackground(Color.white);

        JLabel title = new JLabel("🔐 Login");
        title.setFont(new Font("Arial", Font.BOLD, 24));

        JLabel idLabel = new JLabel("User ID:");
        JLabel passLabel = new JLabel("Password:");

        idField = new JTextField(15);
        passwordField = new JPasswordField(15);

        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");

        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        add(idLabel, gbc);
        gbc.gridx = 1;
        add(idField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(passLabel, gbc);
        gbc.gridx = 1;
        add(passwordField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        add(loginBtn, gbc);
        gbc.gridx = 1;
        add(registerBtn, gbc);

        // 🔐 Login logic
        loginBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            String pass = new String(passwordField.getPassword()).trim();

            for (User u : users) {
                if (u.getId().equals(id) && u.getPassword().equals(pass)) {
                    JOptionPane.showMessageDialog(this, "✅ Welcome " + u.getName());

                    if (u instanceof Worker) {
                        mainWindow.showWorkerDashboard((Worker) u);
                    } else if (u instanceof Employer) {
                        mainWindow.showEmployerDashboard((Employer) u);
                    }
                    return;
                }
            }

            JOptionPane.showMessageDialog(this, "❌ Invalid credentials.");
        });

        // 🔁 Switch to register
        registerBtn.addActionListener(e -> mainWindow.switchTo("register"));
    }
}

package ui;

import model.*;
import service.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class EmployerDashboardPanel extends JPanel {
    private Employer employer;
    private JobBoard board;
    private JTextArea jobsArea;

    public EmployerDashboardPanel(MainWindow window, Employer employer, JobBoard board) {
        this.employer = employer;
        this.board = board;

        setLayout(new BorderLayout());
        setBackground(Color.white);

        JLabel title = new JLabel("🏗️ Employer Dashboard", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        // Center: Job posting form
        JPanel form = new JPanel(new GridLayout(7, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        form.setBackground(Color.white);

        JTextField titleField = new JTextField();
        JTextField categoryField = new JTextField();
        JTextField locationField = new JTextField();
        JTextField wageField = new JTextField();
        JTextArea descArea = new JTextArea(3, 20);

        form.add(new JLabel("Job Title:")); form.add(titleField);
        form.add(new JLabel("Category:")); form.add(categoryField);
        form.add(new JLabel("Location:")); form.add(locationField);
        form.add(new JLabel("Wage per Day (₹):")); form.add(wageField);
        form.add(new JLabel("Description:")); form.add(new JScrollPane(descArea));

        JButton postBtn = new JButton("Post Job");
        form.add(new JLabel());
        form.add(postBtn);

        add(form, BorderLayout.CENTER);

        // Bottom: List of posted jobs
        jobsArea = new JTextArea(8, 40);
        jobsArea.setEditable(false);
        add(new JScrollPane(jobsArea), BorderLayout.SOUTH);
        refreshJobs();

        postBtn.addActionListener(e -> {
            String jobTitle = titleField.getText().trim();
            String cat = categoryField.getText().trim();
            String loc = locationField.getText().trim();
            String wageStr = wageField.getText().trim();
            String desc = descArea.getText().trim();

            if (jobTitle.isEmpty() || cat.isEmpty() || loc.isEmpty() || wageStr.isEmpty() || desc.isEmpty()) {
                JOptionPane.showMessageDialog(this, "❌ Fill in all fields.");
                return;
            }

            int wage = 0;
            try {
                wage = Integer.parseInt(wageStr);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "❌ Wage must be a number.");
                return;
            }

            board.postJob(employer, jobTitle, cat, loc, wage, desc);
            JOptionPane.showMessageDialog(this, "✅ Job Posted!");
            refreshJobs();
            titleField.setText(""); categoryField.setText(""); locationField.setText(""); wageField.setText(""); descArea.setText("");
        });
    }

    private void refreshJobs() {
        List<Job> myJobs = board.getPostedJobsBy(employer);
        StringBuilder sb = new StringBuilder("📋 My Posted Jobs:\n");
        for (Job job : myJobs) {
            sb.append(job).append("\n");
        }
        jobsArea.setText(sb.toString());
    }
}

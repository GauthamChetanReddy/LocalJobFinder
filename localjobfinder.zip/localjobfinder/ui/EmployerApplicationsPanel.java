package ui;

import model.*;
import service.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class EmployerApplicationsPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private Employer employer;
    private List<Application> applications;
    private List<Job> jobs;
    private List<User> users;

    public EmployerApplicationsPanel(Employer employer) {
        this.employer = employer;
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel title = new JLabel("📋 Applications for Your Jobs");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        add(title, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"App ID", "Job Title", "Worker Name", "Status"}, 0);
        table = new JTable(model);
        JScrollPane scroll = new JScrollPane(table);
        add(scroll, BorderLayout.CENTER);

        JButton acceptBtn = new JButton("✅ Accept");
        JButton rejectBtn = new JButton("❌ Reject");

        JPanel btnPanel = new JPanel();
        btnPanel.add(acceptBtn);
        btnPanel.add(rejectBtn);
        add(btnPanel, BorderLayout.SOUTH);

        loadData();

        acceptBtn.addActionListener(e -> updateStatus("Accepted"));
        rejectBtn.addActionListener(e -> updateStatus("Rejected"));
    }

    private void loadData() {
        model.setRowCount(0); // Clear table
        applications = FileManager.loadApplications();
        jobs = FileManager.loadJobs();
        users = FileManager.loadUsers();

        for (Application app : applications) {
            Optional<Job> job = jobs.stream().filter(j -> j.getJobId().equals(app.getJobId()) && j.getPostedBy().equals(employer.getId())).findFirst();
            Optional<User> worker = users.stream().filter(u -> u.getId().equals(app.getWorkerId())).findFirst();

            if (job.isPresent() && worker.isPresent()) {
                model.addRow(new Object[]{app.getAppId(), job.get().getTitle(), worker.get().getName(), app.getStatus()});
            }
        }
    }

    private void updateStatus(String newStatus) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an application first.");
            return;
        }

        String appId = (String) model.getValueAt(row, 0);

        for (Application app : applications) {
            if (app.getAppId().equals(appId)) {
                app.setStatus(newStatus);
                break;
            }
        }

        FileManager.saveAllApplications(applications);
        JOptionPane.showMessageDialog(this, "Status updated to " + newStatus + "!");
        loadData(); // Refresh
    }
}

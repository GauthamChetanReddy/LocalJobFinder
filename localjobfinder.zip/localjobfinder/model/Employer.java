package model;

public class Employer extends User {
    public Employer(String id, String name, String phone, String password) {
        super(id, name, phone, password);
    }

    @Override
    public String getRole() {
        return "Employer";
    }
}

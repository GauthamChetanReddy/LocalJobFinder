package model;

public class Application {
    private String appId;
    private String jobId;
    private String workerId;
    private String status;

    public Application(String appId, String jobId, String workerId, String status) {
        this.appId = appId;
        this.jobId = jobId;
        this.workerId = workerId;
        this.status = status;
    }

    public String getAppId() {
        return appId;
    }

    public String getJobId() {
        return jobId;
    }

    public String getWorkerId() {
        return workerId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return appId + "," + jobId + "," + workerId + "," + status;
    }
}

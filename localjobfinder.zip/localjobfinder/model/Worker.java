package model;

public class Worker extends User {
    public Worker(String id, String name, String phone, String password) {
        super(id, name, phone, password);
    }

    @Override
    public String getRole() {
        return "Worker";
    }
}

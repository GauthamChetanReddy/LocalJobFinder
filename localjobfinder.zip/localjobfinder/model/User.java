package model;

public abstract class User {
    protected String id;
    protected String name;
    protected String phone;
    protected String password;

    public User(String id, String name, String phone, String password) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getPassword() {
        return password;
    }

    public abstract String getRole(); // "Worker" or "Employer"

    @Override
    public String toString() {
        return id + "," + name + "," + phone + "," + password + "," + getRole();
    }
}

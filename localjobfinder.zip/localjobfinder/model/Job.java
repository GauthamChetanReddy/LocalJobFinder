package model;

public class Job {
    private String jobId;
    private String title;
    private String category;
    private String location;
    private int wage;  // ✅ Field exists
    private String description;
    private String postedBy;

    public Job(String jobId, String title, String category, String location, int wage, String description, String postedBy) {
        this.jobId = jobId;
        this.title = title;
        this.category = category;
        this.location = location;
        this.wage = wage;
        this.description = description;
        this.postedBy = postedBy;
    }

    // ✅ Getter for daily wage (match your usage in JobBoard)
    public int getDailyWage() {
        return this.wage;
    }

    // Optional: a general getter
    public int getWage() {
        return this.wage;
    }

    // You may already have this
    @Override
    public String toString() {
        return jobId + "," + title + "," + category + "," + location + "," + wage + "," + description + "," + postedBy;
    }

    // Other getters
    public String getJobId() { return jobId; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public String getLocation() { return location; }
    public String getDescription() { return description; }
    public String getPostedBy() { return postedBy; }
}

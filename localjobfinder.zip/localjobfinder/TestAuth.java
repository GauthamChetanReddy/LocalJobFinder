import service.AuthService;
import model.User;

public class TestAuth {
    public static void main(String[] args) {
        AuthService auth = new AuthService();

        // Test registration
        User newUser = auth.register("Gautham Reddy", "9876543210", "pass123", "Worker");
        if (newUser != null) {
            System.out.println("✅ Registered: " + newUser.getName());
        }

        // Test login
        User loggedIn = auth.login("9876543210", "pass123");
        if (loggedIn != null) {
            System.out.println("✅ Logged in: " + loggedIn.getName() + " (" + loggedIn.getRole() + ")");
        } else {
            System.out.println("❌ Login failed.");
        }
    }
}

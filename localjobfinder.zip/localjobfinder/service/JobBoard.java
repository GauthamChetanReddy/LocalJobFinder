package service;

import model.*;
import java.util.*;

public class JobBoard {
    private List<Job> jobs;
    private List<Application> applications;
    private List<User> users;

    public JobBoard() {
        this.jobs = FileManager.loadJobs();
        this.applications = FileManager.loadApplications();
        this.users = FileManager.loadUsers();
    }

    // ----------------------------------------
    // ✅ Employer Posts a Job
    public void postJob(Employer employer, String title, String category,
                        String location, int wage, String desc) {
        String jobId = "J" + (jobs.size() + 1);
        Job job = new Job(jobId, title, category, location, wage, desc, employer.getId());
        jobs.add(job);
        FileManager.saveJob(job);
        System.out.println("✅ Job posted with ID: " + jobId);
    }

    // ----------------------------------------
    // 👀 Worker Browses All Jobs
    public void showAllJobs() {
        System.out.println("\n📋 Available Jobs:");
        for (Job job : jobs) {
            System.out.println("ID: " + job.getJobId() + " | " + job.getTitle() +
                               " | " + job.getLocation() + " | ₹" + job.getDailyWage() +
                               " | Category: " + job.getCategory());
        }
    }

    // ----------------------------------------
    // 📨 Worker Applies to a Job
    public void applyToJob(Worker worker, String jobId) {
        Optional<Job> job = jobs.stream()
                                .filter(j -> j.getJobId().equals(jobId))
                                .findFirst();

        if (!job.isPresent()) {
            System.out.println("❌ Job not found.");
            return;
        }

        // Prevent duplicate applications
        for (Application app : applications) {
            if (app.getJobId().equals(jobId) && app.getWorkerId().equals(worker.getId())) {
                System.out.println("⚠️ You already applied to this job.");
                return;
            }
        }

        String appId = "A" + (applications.size() + 1);
        Application newApp = new Application(appId, jobId, worker.getId(), "Applied");
        applications.add(newApp);
        FileManager.saveApplication(newApp);
        System.out.println("✅ Application submitted with ID: " + appId);
    }

    // ----------------------------------------
    // 📄 Show All Applications by a Worker
    public void showMyApplications(Worker worker) {
        System.out.println("\n📂 Your Applications:");
        for (Application app : applications) {
            if (app.getWorkerId().equals(worker.getId())) {
                System.out.println("Job ID: " + app.getJobId() + " | Status: " + app.getStatus());
            }
        }
    }
    // Add inside JobBoard.java

public List<Job> getPostedJobsBy(Employer employer) {
    List<Job> result = new ArrayList<>();
    for (Job job : jobs) {
        if (job.getPostedBy().equals(employer.getId())) {
            result.add(job);
        }
    }
    return result;
}

public List<Application> getApplicationsByWorker(String workerId) {
    List<Application> result = new ArrayList<>();
    for (Application app : applications) {
        if (app.getWorkerId().equals(workerId)) {
            result.add(app);
        }
    }
    return result;
}

public Job getJobById(String jobId) {
    for (Job job : jobs) {
        if (job.getJobId().equals(jobId)) {
            return job;
        }
    }
    return null;
}

    // 📄 Show Jobs Posted by Employer
    public void showPostedJobs(Employer emp) {
        System.out.println("\n📌 Jobs You've Posted:");
        for (Job job : jobs) {
            if (job.getPostedBy().equals(emp.getId())) {
                System.out.println("ID: " + job.getJobId() + " | Title: " + job.getTitle());
            }
        }
    }
}

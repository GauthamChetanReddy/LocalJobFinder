package service;

import model.*;

import java.io.*;
import java.util.*;

public class FileManager {

    private static final String USERS_FILE = "data/users.txt";
    private static final String JOBS_FILE = "data/jobs.txt";
    private static final String APPLICATIONS_FILE = "data/applications.txt";

    // ---------------- Users ----------------
    public static List<User> loadUsers() {
        List<User> users = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 5) continue;
                String id = parts[0];
                String name = parts[1];
                String phone = parts[2];
                String password = parts[3];
                String role = parts[4];

                if (role.equalsIgnoreCase("Worker")) {
                    users.add(new Worker(id, name, phone, password));
                } else if (role.equalsIgnoreCase("Employer")) {
                    users.add(new Employer(id, name, phone, password));
                }
            }
        } catch (IOException e) {
            System.out.println("⚠️ Could not load users: " + e.getMessage());
        }
        return users;
    }

    public static void saveUser(User user) {
        try (FileWriter fw = new FileWriter(USERS_FILE, true)) {
            fw.write(user.toString() + "\n");
        } catch (IOException e) {
            System.out.println("⚠️ Could not save user: " + e.getMessage());
        }
    }

    // ---------------- Jobs ----------------
    public static List<Job> loadJobs() {
        List<Job> jobs = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(JOBS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 7);
                if (parts.length < 7) continue;
                Job job = new Job(parts[0], parts[1], parts[2], parts[3],
                                  Integer.parseInt(parts[4]), parts[5], parts[6]);
                jobs.add(job);
            }
        } catch (IOException e) {
            System.out.println("⚠️ Could not load jobs: " + e.getMessage());
        }
        return jobs;
    }

    public static void saveJob(Job job) {
        try (FileWriter fw = new FileWriter(JOBS_FILE, true)) {
            fw.write(job.toString() + "\n");
        } catch (IOException e) {
            System.out.println("⚠️ Could not save job: " + e.getMessage());
        }
    }

    // ---------------- Applications ----------------
    public static List<Application> loadApplications() {
        List<Application> apps = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(APPLICATIONS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 4) continue;
                Application app = new Application(parts[0], parts[1], parts[2], parts[3]);
                apps.add(app);
            }
        } catch (IOException e) {
            System.out.println("⚠️ Could not load applications: " + e.getMessage());
        }
        return apps;
    }

    public static void saveApplication(Application app) {
        try (FileWriter fw = new FileWriter(APPLICATIONS_FILE, true)) {
            fw.write(app.toString() + "\n");
        } catch (IOException e) {
            System.out.println("⚠️ Could not save application: " + e.getMessage());
        }
    }

    // ✅ Save all applications (overwrite file)
    public static void saveAllApplications(List<Application> apps) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(APPLICATIONS_FILE))) {
            for (Application app : apps) {
                pw.println(app.toString());
            }
        } catch (IOException e) {
            System.out.println("⚠️ Could not save applications: " + e.getMessage());
        }
    }
}

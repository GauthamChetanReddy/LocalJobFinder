package service;

import model.*;
import java.util.*;

public class AuthService {

    private List<User> users;

    public AuthService() {
        this.users = FileManager.loadUsers();
    }

    public User login(String phone, String password) {
        for (User user : users) {
            if (user.getPhone().equals(phone) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    public boolean phoneExists(String phone) {
        for (User user : users) {
            if (user.getPhone().equals(phone)) {
                return true;
            }
        }
        return false;
    }

    public User register(String name, String phone, String password, String role) {
        if (phoneExists(phone)) {
            System.out.println("⚠️ Phone already registered.");
            return null;
        }

        String userId = "U" + (users.size() + 1); // You can replace with UUID if needed
        User newUser;

        if (role.equalsIgnoreCase("Worker")) {
            newUser = new Worker(userId, name, phone, password);
        } else if (role.equalsIgnoreCase("Employer")) {
            newUser = new Employer(userId, name, phone, password);
        } else {
            System.out.println("❌ Invalid role.");
            return null;
        }

        FileManager.saveUser(newUser);
        users.add(newUser);
        return newUser;
    }
}
